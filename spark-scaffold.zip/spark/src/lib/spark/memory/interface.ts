export type MemoryKind = "short_term" | "long_term" | "semantic" | "episodic" | "workspace";

export interface MemoryRecord {
  id: string;
  kind: MemoryKind;
  sessionId?: string;
  userId?: string;
  content: string;
  tags?: string[];
  createdAt: string;
}

export interface MemoryQuery {
  kind?: MemoryKind;
  sessionId?: string;
  userId?: string;
  tag?: string;
  text?: string;
  limit?: number;
}

export interface MemoryService {
  remember(input: {
    kind: MemoryKind;
    content: string;
    sessionId?: string;
    userId?: string;
    tags?: string[];
  }): MemoryRecord;

  recall(query: MemoryQuery): MemoryRecord[];

  forget(id: string): boolean;

  clearSession(sessionId: string): number;

  size(): number;
}
