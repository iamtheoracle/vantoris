/**
 * These types belong to UNIBUD only. Spark and Bud know nothing about
 * "tools," "goals," or a "dashboard" — those are UNIBUD's own concepts,
 * built on top of the frozen Spark/Bud SDKs.
 */

export type ToolId =
  | "assignments"
  | "projects"
  | "smart_notes"
  | "study_plans"
  | "campus"
  | "connect";

export interface ToolDefinition {
  id: ToolId;
  name: string;
  description: string;
  tags: string[];
}

export interface DashboardViewModel {
  greeting: string;
  tools: ToolDefinition[];
  suggestedToolId: ToolId | null;
  suggestedReason: string;
  trace: {
    memoryHits: number;
    knowledgeHits: number;
    reasoningConfidence: number;
    provider: string;
  };
}
