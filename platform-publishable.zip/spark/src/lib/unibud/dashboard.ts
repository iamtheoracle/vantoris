import type { Spark } from "../spark";
import type { Bud } from "../bud";
import type { BudSession } from "../bud";
import type { DashboardViewModel } from "./types";
import { TOOL_DEFINITIONS } from "./tools";
import { getGoals } from "./goals";

/**
 * The landing-page flow described in the product brief:
 *
 *   1. Bud greets the student and reasons over their message (via Bud's
 *      own respond() — UNIBUD does not reimplement conversation).
 *   2. Spark.recommendations ranks UNIBUD's own tool catalog against
 *      the student's stored goal tags — a dashboard-level concern Bud
 *      doesn't expose, so UNIBUD calls Spark directly for it.
 *
 * Bud and Spark's public APIs are used exactly as frozen; nothing here
 * reaches into their internals.
 */
export async function assembleDashboard(
  spark: Spark,
  bud: Bud,
  session: BudSession,
  message?: string
): Promise<DashboardViewModel> {
  const response = await bud.respond(
    message ?? "Greet me and help me figure out what to work on.",
    session
  );

  const goalTags = getGoals(spark, session.userId);

  const ranked = spark.recommendations.recommend({
    userId: session.userId,
    sessionId: session.sessionId,
    candidateItems: TOOL_DEFINITIONS.map((t) => ({ id: t.id, tags: t.tags })),
    basedOnTags: goalTags,
    limit: 1,
  });

  const top = ranked[0];
  const suggestedToolId = top && top.score > 0 ? (top.itemId as DashboardViewModel["suggestedToolId"]) : null;

  return {
    greeting: response.message,
    tools: TOOL_DEFINITIONS,
    suggestedToolId,
    suggestedReason: top?.reason ?? "Set an academic goal to get a personalized pick here.",
    trace: {
      memoryHits: response.trace.memoryHits,
      knowledgeHits: response.trace.knowledgeHits,
      reasoningConfidence: response.trace.reasoningConfidence,
      provider: response.trace.provider,
    },
  };
}
