import type { Spark } from "../spark";

const GOALS_KEY = "academic_goal_tags";

/**
 * UNIBUD-specific convenience over Spark.personalization. Spark itself
 * has no concept of "academic goals" — it just stores arbitrary tagged
 * preferences per user. This is where UNIBUD gives that generic
 * mechanism product meaning.
 */
export function setGoals(spark: Spark, userId: string, tags: string[]): void {
  spark.personalization.setPreference(userId, GOALS_KEY, tags);
}

export function getGoals(spark: Spark, userId: string): string[] {
  const pref = spark.personalization.getPreference(userId, GOALS_KEY);
  return Array.isArray(pref?.value) ? (pref!.value as string[]) : [];
}
