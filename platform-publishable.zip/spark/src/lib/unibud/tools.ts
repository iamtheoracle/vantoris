import type { ToolDefinition } from "./types";

/**
 * Static configuration, not intelligence. Tags here are matched against
 * a student's stored goal tags (via Spark's Personalization service) to
 * drive the "suggested next" pick on the dashboard.
 */
export const TOOL_DEFINITIONS: ToolDefinition[] = [
  {
    id: "assignments",
    name: "Assignments",
    description: "Track what's due and what's done.",
    tags: ["deadlines", "coursework", "grades"],
  },
  {
    id: "projects",
    name: "Projects",
    description: "Longer-running work with milestones.",
    tags: ["coursework", "collaboration", "deadlines"],
  },
  {
    id: "smart_notes",
    name: "Smart Notes",
    description: "Notes that connect back to your courses.",
    tags: ["coursework", "study", "review"],
  },
  {
    id: "study_plans",
    name: "Study Plans",
    description: "A sequenced plan for an exam or a subject.",
    tags: ["study", "review", "grades"],
  },
  {
    id: "campus",
    name: "Campus",
    description: "Events, deadlines, and services at your school.",
    tags: ["campus_life", "community"],
  },
  {
    id: "connect",
    name: "Connect",
    description: "Study groups, mentors, and classmates.",
    tags: ["community", "collaboration"],
  },
];
