import { createSpark } from "../src/lib/spark";
import { createBud } from "../src/lib/bud";
import { assembleDashboard, setGoals } from "../src/lib/unibud";

async function main() {
  const spark = createSpark();
  await spark.initialize();
  const bud = createBud({ spark, personality: { name: "Bud", tone: "casual" } });

  const session = { sessionId: "unibud_s1", userId: "student_1", product: "unibud" };

  console.log("--- Dashboard with no stated goals yet ---");
  const first = await assembleDashboard(spark, bud, session);
  console.log(JSON.stringify(first, null, 2));
  if (first.suggestedToolId !== null) {
    throw new Error("Expected no suggestion before any goals are set.");
  }

  console.log("\n--- Student sets a goal, asks a real question ---");
  setGoals(spark, session.userId, ["grades", "review"]);
  const second = await assembleDashboard(
    spark,
    bud,
    session,
    "I have a chemistry exam next week, what should I focus on?"
  );
  console.log(JSON.stringify(second, null, 2));

  if (!second.suggestedToolId) {
    throw new Error("Expected a suggested tool once goal tags are set.");
  }
  if (!["study_plans", "assignments"].includes(second.suggestedToolId)) {
    throw new Error(
      `Expected study_plans or assignments to rank highest for ["grades","review"], got ${second.suggestedToolId}`
    );
  }

  console.log("\n--- Transcript is readable straight from Bud/Spark, UNIBUD stores nothing of its own ---");
  console.log(bud.transcript(session.sessionId));

  await spark.shutdown();
  console.log("\nUNIBUD dashboard verification completed successfully.");
}

main().catch((err) => {
  console.error("UNIBUD verification failed:", err);
  throw err;
});
