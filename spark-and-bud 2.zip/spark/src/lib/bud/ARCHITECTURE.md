# Bud — Architecture

## Position in the ecosystem

```
User
  │
  ▼
Bud            (personality + orchestration only)
  │
  ▼
Spark           (all intelligence: memory, context, reasoning, planning,
  │              knowledge, search, writing, translation, privacy,
  │              security, automation, learning)
  ▼
AI Provider     (Mock by default; OpenAI/Anthropic/Gemini/local when configured)
```

Bud never skips Spark to reach the AI provider layer directly, and Spark
never imports or knows about Bud.

## Directory layout

```
src/lib/bud/
├── index.ts              Public SDK — createBud(). The only supported import.
├── config.ts              Static limits (recall/search result counts).
├── types.ts                 Session, message, and response shapes.
├── personality.ts             Static tone/voice configuration.
├── orchestrator.ts              The respond() flow, step by step.
├── conversation.ts                Transcript formatting over Spark memory (no storage of its own).
├── prompts/
│   ├── systemPrompt.ts               Builds the system prompt from personality config.
│   └── userPrompt.ts                  Builds the user-turn prompt from Spark's outputs.
├── actions/
│   ├── recallMemory.ts                  Calls spark.memory.recall
│   ├── searchKnowledge.ts                 Calls spark.search.search
│   ├── reason.ts                            Calls spark.reasoning.analyze
│   ├── planIfNeeded.ts                        Mechanical step detection -> spark.planning.createPlan
│   ├── generateResponse.ts                      Calls spark.writing.draft
│   └── storeInteraction.ts                        Calls spark.memory.remember
├── context/
│   └── buildContext.ts                              Ensures spark.identity has a context for the session
└── adapters/
    ├── sparkPort.ts                                    The narrow interface Bud is allowed to depend on
    └── liveSparkAdapter.ts                               Wraps a real Spark instance to satisfy that interface
```

## The respond() flow

`bud.respond(message, session)` runs exactly these steps, in order,
every time:

1. **Build context** — `context/buildContext.ts` asks Spark's Identity
   service whether this session already has a context; creates one if not.
2. **Recall memory** — `actions/recallMemory.ts` asks Spark for prior
   episodic memory tied to this session.
3. **Search knowledge** — `actions/searchKnowledge.ts` asks Spark's
   Search service (which itself only talks to Knowledge) for anything
   relevant to the message.
4. **Reason** — `actions/reason.ts` hands the message plus everything
   recalled/found to Spark's Reasoning service and gets back an answer,
   a confidence score, and an explainable step trace.
5. **Plan (conditionally)** — `actions/planIfNeeded.ts` does a
   mechanical check (keyword/punctuation split, not semantic
   understanding) for whether the message looks like multiple
   sequenced asks. If so, it hands the extracted steps to Spark's
   Planning service. If not, no plan is created and no planning call
   is made.
6. **Generate response** — `actions/generateResponse.ts` builds a
   prompt (system prompt from personality + user prompt from Spark's
   reasoning/memory/knowledge outputs) and calls `spark.writing.draft()`.
   Spark resolves whichever `AIProvider` is registered — Bud never
   knows or cares which one.
7. **Store the turn** — `actions/storeInteraction.ts` writes both the
   user's message and Bud's reply back into Spark memory as episodic
   records, tagged `user`/`bud`.

Every one of those seven steps is a call through `BudSparkPort` — the
orchestrator (`orchestrator.ts`) contains no branching logic that
depends on the *content* of the message beyond step 5's mechanical
split. It doesn't summarize, doesn't judge relevance, doesn't decide
what's true — it delegates all of that.

## Why `adapters/sparkPort.ts` exists

`BudSparkPort` is a deliberately narrow re-typing of Spark's public
surface — only `identity`, `memory`, `search`, `reasoning`, `planning`,
and `writing`. Two consequences:

- **It's structurally impossible for Bud's action files to reach a
  capability that isn't listed** — there is no `providers` field on
  the port, so Bud cannot call an `AIProvider` even by mistake.
- **Bud is independently testable.** Anything satisfying
  `BudSparkPort`'s shape can stand in for Spark in a test, without
  spinning up a real Spark instance. `adapters/liveSparkAdapter.ts` is
  the only file that touches the concrete `Spark` class.

## Where conversation history actually lives

`conversation.ts` has no storage of its own. `getTranscript()` reads
Spark's episodic memory for a session and reshapes matched
user/bud record pairs into `ConversationTurn[]`. If Spark's memory for
that session is cleared, the transcript is gone — there is no shadow
copy inside Bud.

## Product independence

`BudSession.product` is passed straight through to Spark's identity and
context services without Bud inspecting or branching on its value.
There is no `if (product === "unibud")` anywhere in this module, and
there must never be — that would turn Bud from a reusable companion
into a product-specific one. New products reuse this exact module by
supplying their own `product` string.

## What's deliberately not here yet

- No persistence beyond whatever Spark itself persists (currently
  in-memory, see the Spark scaffold's README).
- No streaming responses — `writing.draft()` returns a complete string.
- No multi-turn planning follow-through (Bud creates a plan via step 5
  but does not yet check `spark.planning.nextTask()` on later turns to
  walk through it turn-by-turn).
- No integration into UNIBUD, My Realm, Orbit, or any application.
