# Bud — the reusable companion layer

Bud is a thin orchestration layer that sits between a user and Spark. It
holds a personality and a conversation flow — nothing else. All memory,
reasoning, planning, search, and text generation come from Spark.

```ts
import { createBud } from "@/lib/bud";

const bud = createBud();

const response = await bud.respond("What's my next task, then remind me to email Sam?", {
  sessionId: "session_1",
  userId: "user_1",
  product: "unibud",
});

console.log(response.message);
console.log(response.trace); // { memoryHits, knowledgeHits, reasoningConfidence, plannedTaskCount, provider }
```

Consumers should only ever `import { createBud } from "@/lib/bud"`.
Nothing under `bud/orchestrator.ts`, `bud/actions/*`, `bud/adapters/*`,
etc. is a supported import path.

## What Bud does NOT do

- Bud does not remember anything itself — `spark.memory` does.
- Bud does not search or retrieve anything itself — `spark.search` does.
- Bud does not reason about the message itself — `spark.reasoning` does.
- Bud does not plan multi-step goals itself — `spark.planning` does,
  once Bud has mechanically noticed the message looks like several steps.
- Bud does not call an AI provider, ever — `spark.writing` does, and
  only Spark decides which provider handles that call.

See `ARCHITECTURE.md` for the full request flow and the reasoning behind
each of these boundaries.

## Sharing a Spark instance

By default `createBud()` creates its own private Spark instance. If you
want multiple Bud instances (or Bud plus another future assistant) to
share memory/knowledge/identity, pass one in:

```ts
import { createSpark } from "@/lib/spark";
import { createBud } from "@/lib/bud";

const spark = createSpark();
await spark.initialize();

const bud = createBud({ spark });
```

## Personality

Personality is plain configuration — a name, tone, and a few voice
guidelines folded into the system prompt Bud sends to Spark's writing
service. It contains no logic:

```ts
const bud = createBud({
  personality: {
    name: "Bud",
    tone: "concise",
    voice: ["Always suggest one concrete next step."],
  },
});
```

## Reusability

Bud has no reference to UNIBUD, My Realm, Orbit, or any other product.
The `product` field on `BudSession` is passed straight through to
Spark's identity/context services — Bud doesn't interpret it. Any
product can use the same Bud module by supplying its own sessions.
