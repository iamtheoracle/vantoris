import { createSpark } from "../src/lib/spark";
import { createBud } from "../src/lib/bud";

async function main() {
  const spark = createSpark();
  await spark.initialize();

  spark.knowledge.addDocument({
    title: "Refund Policy",
    content: "Refunds are issued within 5 business days of a return request.",
    tags: ["policy", "refunds"],
  });

  const bud = createBud({ spark, personality: { name: "Bud", tone: "concise" } });

  const session = { sessionId: "s1", userId: "u1", product: "unibud" };

  console.log("--- Turn 1: simple question ---");
  const r1 = await bud.respond("What is your refund policy?", session);
  console.log(r1);

  console.log("\n--- Turn 2: multi-step message (should trigger planning) ---");
  const r2 = await bud.respond(
    "Check my refund status then email me a confirmation",
    session
  );
  console.log(r2);
  if (r2.trace.plannedTaskCount < 2) {
    throw new Error("Expected planIfNeeded to detect a multi-step request.");
  }

  console.log("\n--- Turn 3: memory should now include prior turns ---");
  const r3 = await bud.respond("What did I just ask you?", session);
  console.log(r3);
  if (r3.trace.memoryHits === 0) {
    throw new Error("Expected memory recall to find prior turns.");
  }

  console.log("\n--- Transcript (read back purely from Spark memory) ---");
  const transcript = bud.transcript(session.sessionId);
  console.log(JSON.stringify(transcript, null, 2));
  if (transcript.length < 2) {
    throw new Error("Expected at least two stored conversation turns.");
  }

  console.log("\n--- Spark health after Bud usage ---");
  console.log(spark.health());

  await spark.shutdown();
  console.log("\nBud verification completed successfully.");
}

main().catch((err) => {
  console.error("Bud verification failed:", err);
  throw err;
});
