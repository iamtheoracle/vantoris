import { createSpark, loggingMiddleware } from "../src/lib/spark";

async function main() {
  const spark = createSpark();
  spark.use(loggingMiddleware);
  await spark.initialize();

  console.log("=== manifest ===");
  console.log(JSON.stringify(spark.manifest(), null, 2));

  console.log("\n=== capabilities ===");
  console.log(spark.capabilities());

  // Identity
  const identity = spark.identity.createContext({
    userId: "user_1",
    sessionId: "session_1",
    product: "smoke-test",
  });
  console.log("\n=== identity ===", identity);

  // Memory
  spark.memory.remember({
    kind: "short_term",
    content: "The user asked about Spark's architecture.",
    sessionId: "session_1",
    userId: "user_1",
  });
  console.log("\n=== memory recall ===", spark.memory.recall({ sessionId: "session_1" }));

  // Context
  spark.context.setAttribute("session_1", "currentScreen", "dashboard");
  console.log("\n=== context snapshot ===", spark.context.getSnapshot("session_1", "smoke-test"));

  // Knowledge + Search
  spark.knowledge.addDocument({
    title: "Spark Overview",
    content: "Spark is the Universal Intelligence System that powers products across the ecosystem.",
    tags: ["spark", "architecture"],
  });
  const searchResults = await spark.search.search("universal intelligence");
  console.log("\n=== search ===", searchResults);

  // Reasoning
  const reasoning = await spark.reasoning.analyze({
    question: "Should Bud call Spark or an AI provider directly?",
    facts: ["Bud must not contain intelligence or business logic."],
  });
  console.log("\n=== reasoning ===", reasoning);

  // Planning
  const plan = spark.planning.createPlan("Ship Spark v1", [
    "Define public API",
    "Implement local services",
    "Run production review",
  ]);
  console.log("\n=== planning ===", plan, spark.planning.nextTask(plan.id));

  // Recommendations
  console.log(
    "\n=== recommendations ===",
    spark.recommendations.recommend({
      candidateItems: [
        { id: "a", tags: ["spark"] },
        { id: "b", tags: ["unrelated"] },
      ],
      basedOnTags: ["spark"],
    })
  );

  // Organization
  console.log(
    "\n=== organization ===",
    spark.organization.groupByTag([
      { id: "1", label: "doc a", tags: ["spark"] },
      { id: "2", label: "doc b", tags: ["bud"] },
    ])
  );

  // Personalization
  spark.personalization.setPreference("user_1", "theme", "dark");
  console.log("\n=== personalization ===", spark.personalization.getAllPreferences("user_1"));

  // Writing / Translation / Summaries (mock provider)
  console.log("\n=== writing ===", await spark.writing.draft({ prompt: "Say hello." }));
  console.log(
    "\n=== translation ===",
    await spark.translation.translate({ text: "Hello", targetLocale: "es-ES" })
  );
  console.log(
    "\n=== summaries ===",
    spark.summaries.summarize({
      text: "Spark is the Universal Intelligence System. It powers Bud, Realm Assistant, and Orbit Assistant. It remains product-agnostic.",
      maxSentences: 1,
    })
  );

  // Privacy / Security
  console.log(
    "\n=== privacy scan ===",
    spark.privacy.scanForPii("Contact me at test@example.com")
  );
  console.log(
    "\n=== security check ===",
    spark.security.checkInput("Please verify your password immediately")
  );

  // Automation
  spark.automation.registerTask("ping", async () => "pong");
  console.log("\n=== automation ===", await spark.automation.run("ping"));

  // Learning
  spark.learning.recordFeedback({ subject: "writing", rating: "positive" });
  console.log("\n=== learning score ===", spark.learning.score("writing"));

  // Health
  console.log("\n=== health ===", spark.health());

  await spark.shutdown();
  console.log("\nSmoke test completed successfully.");
}

main().catch((err) => {
  console.error("Smoke test failed:", err);
  throw err;
});
