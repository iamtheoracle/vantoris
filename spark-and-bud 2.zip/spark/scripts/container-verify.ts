import { createSpark } from "../src/lib/spark";
import { Container } from "../src/lib/spark/container";
import { ServiceNotRegisteredError } from "../src/lib/spark/errors";

async function main() {
  const spark = createSpark();
  console.log("modules():", spark.modules());
  console.log("manifest().registeredModules:", spark.manifest().registeredModules);

  // registerValue + missing-token error behavior, isolated from Spark's own container
  const c = new Container();
  const sentinel = { ok: true };
  const token = Symbol("test.value");
  c.registerValue(token, sentinel);
  const resolved = c.resolve<typeof sentinel>(token);
  if (resolved !== sentinel) throw new Error("registerValue did not preserve identity");
  console.log("registerValue OK, resolved instance === original:", resolved === sentinel);

  try {
    c.resolve(Symbol("never.registered"));
    throw new Error("expected ServiceNotRegisteredError to be thrown");
  } catch (err) {
    if (!(err instanceof ServiceNotRegisteredError)) {
      throw new Error(`expected ServiceNotRegisteredError, got ${err}`);
    }
    console.log("ServiceNotRegisteredError thrown correctly:", err.message);
  }

  // Per-instance isolation: two Spark instances never share a container
  const sparkA = createSpark();
  const sparkB = createSpark();
  sparkA.memory.remember({ kind: "short_term", content: "only in A" });
  const crossLeak = sparkB.memory.recall({ text: "only in A" });
  if (crossLeak.length !== 0) throw new Error("Spark instances are leaking state!");
  console.log("Per-instance isolation OK: sparkB sees", crossLeak.length, "matching records");

  console.log("\nContainer verification completed successfully.");
}

main().catch((err) => {
  console.error("Container verification failed:", err);
  throw err;
});
