/**
 * Minimal dependency-injection container.
 *
 * Services are registered as factories and resolved lazily on first
 * use, then cached as singletons for the lifetime of the Spark instance
 * that owns this container. Each `createSpark()` call gets its own
 * container, so multiple Spark instances never share state.
 */

export const TOKENS = {
  Identity: "core.identity",
  Reasoning: "core.reasoning",
  Planning: "core.planning",
  Memory: "memory",
  Context: "context",
  Knowledge: "knowledge",
  Search: "intelligence.search",
  Recommendations: "intelligence.recommendations",
  Organization: "intelligence.organization",
  Personalization: "intelligence.personalization",
  Writing: "intelligence.writing",
  Translation: "intelligence.translation",
  Summaries: "intelligence.summaries",
  Privacy: "trust.privacy",
  Security: "trust.security",
  Automation: "automation",
  Learning: "learning",
  ProviderRegistry: "providers.registry",
} as const;

export type Token = (typeof TOKENS)[keyof typeof TOKENS] | string;

type Factory<T> = (container: Container) => T;

export class Container {
  private factories = new Map<Token, Factory<unknown>>();
  private instances = new Map<Token, unknown>();

  register<T>(token: Token, factory: Factory<T>): void {
    this.factories.set(token, factory as Factory<unknown>);
    // Invalidate any cached instance so re-registration is respected.
    this.instances.delete(token);
  }

  has(token: Token): boolean {
    return this.factories.has(token);
  }

  resolve<T>(token: Token): T {
    if (this.instances.has(token)) {
      return this.instances.get(token) as T;
    }
    const factory = this.factories.get(token);
    if (!factory) {
      throw new Error(`No service registered for token "${token}".`);
    }
    const instance = factory(this);
    this.instances.set(token, instance);
    return instance as T;
  }

  /** Tokens that currently have a registered factory. */
  registeredTokens(): Token[] {
    return Array.from(this.factories.keys());
  }

  /** Tokens that have actually been instantiated (lazy resolution check). */
  resolvedTokens(): Token[] {
    return Array.from(this.instances.keys());
  }

  reset(): void {
    this.instances.clear();
  }
}
